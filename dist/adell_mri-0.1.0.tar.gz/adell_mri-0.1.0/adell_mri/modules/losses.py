from .classification.losses import *
from .segmentation.losses import *
from .object_detection.losses import *
from .self_supervised.losses import *
